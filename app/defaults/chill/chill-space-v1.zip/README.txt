LEAP Chill Pack: Weltraum
Sterne und Parallax-Bewegung sollen prozedural erzeugt werden.
Der Slider 0-100 steuert die Flug-/Sternengeschwindigkeit.
Die PNGs sind optionale, selten eingeblendete Dekorationen.
