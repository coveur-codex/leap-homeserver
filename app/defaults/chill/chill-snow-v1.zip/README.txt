LEAP Chill Pack: Schnee
Schneeflocken und Winddrift sollen prozedural erzeugt werden.
Der Slider 0-100 steuert Schneemenge und leicht die Wind-/Fallgeschwindigkeit.
Die PNGs bilden nur Landschafts-/Deko-Elemente.
