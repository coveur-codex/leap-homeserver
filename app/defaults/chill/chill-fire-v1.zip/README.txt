LEAP Chill Pack: Lagerfeuer
Die Flamme besteht aus 6 Frames. Holz und Glut sind statisch.
Funken/kleine Glutpartikel sollen prozedural erzeugt werden.
Der Slider 0-100 steuert Intensität: Flammenskalierung, FPS und Funkenmenge.
